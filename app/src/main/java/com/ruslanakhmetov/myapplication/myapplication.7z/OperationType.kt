package com.ruslanakhmetov.myapplication

enum class OperationType {
    EXPENSE,
    INCOME
}