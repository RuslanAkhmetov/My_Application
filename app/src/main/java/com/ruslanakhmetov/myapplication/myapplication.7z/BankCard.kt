package com.ruslanakhmetov.myapplication

data class BankCard(
    val bankName: String,
    val cardPan: String,
    var balance: Double
    )

