package com.ruslanakhmetov.myapplication

enum class TransactionSource {
    ПРОДУКТЫ, ТРАНСПОРТ, РАЗВЛЕЧЕНИЯ
}
