package com.ruslanakhmetov.myapplication

import java.util.Date

data class SMS(val date: Long, val sender: String, val body: String){

}
