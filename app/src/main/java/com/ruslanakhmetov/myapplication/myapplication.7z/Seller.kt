package com.ruslanakhmetov.myapplication

data class Seller(
    val name: String,
    val transactionSource: TransactionSource
    )
